﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TutoFinder.Commons
{
    public class RoleHelper
    {
        public const string Admin = "ADMIN";
        public const string Padre = "PADRE";
        public const string Docente = "DOCENTE";
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Model;

namespace WebApplication1.Dto
{
    public class HijoCreateDto
    {
        
        public string Nombres { get; set; }
        public string AñoEscolar { get; set; }
        public int PadreId { get; set; }
    }
    public class HijoUpdateDto
    {
        
        public string Nombres { get; set; }
        public string AñoEscolar { get; set; }
        public int PadreId { get; set; }
    }
    public class HijoDto
    {
        
        public int HijoId { get; set; }
        public string Nombres { get; set; }
        public string AñoEscolar { get; set; }
        public int PadreNombre { get; set; }
    }
}

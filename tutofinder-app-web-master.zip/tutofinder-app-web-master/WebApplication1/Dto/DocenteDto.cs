﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Model;

namespace WebApplication1.Dto
{
    public class DocenteCreateDto
    {
        
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public int Edad { get; set; }
        public List<Anuncio> Anuncios { get; set; }
    }
    public class DocenteUpdateDto
    {
        
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public int Edad { get; set; }
        public List<Anuncio> Anuncios { get; set; }
    }
    public class DocenteDto
    {
        public int DocenteId { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public int Edad { get; set; }
        public List<Anuncio> Anuncios { get; set; }

    }
}

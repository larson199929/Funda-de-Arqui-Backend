﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Dto
{
    public class AnuncioCreateDto
    {

        public int AnuncioId { get; set; }
        public string Area { get; set; }
        public string Curso { get; set; }
        public string EtapaEscolar { get; set; }
        public double Duracion { get; set; }
        public double HoraInicio { get; set; }
        public double HoraFin { get; set; }
        public int DocenteId { get; set; }
    }
    public class AnuncioUpdateDto
    {

        public int AnuncioId { get; set; }
        public string Area { get; set; }
        public string Curso { get; set; }
        public string EtapaEscolar { get; set; }
        public double Duracion { get; set; }
        public double HoraInicio { get; set; }
        public double HoraFin { get; set; }
        public int DocenteId { get; set; }
    }
    public class AnuncioDto
    {
        public int AnuncioId { get; set; }
        public string Area { get; set; }
        public string Curso { get; set; }
        public string EtapaEscolar { get; set; }
        public double Duracion { get; set; }
        public double HoraInicio { get; set; }
        public double HoraFin { get; set; }
        public string DocenteNombre { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiTodo.Commons;
using WebApplication1.Dto;
using WebApplication1.Model;
using WebApplication1.Service;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("anuncios")]
    public class AnuncioController : ControllerBase
    {
        private readonly AnuncioService _anuncioService;

        public AnuncioController(AnuncioService anuncioService)
        {
            _anuncioService = anuncioService;
        }
        [HttpGet]
        public ActionResult<DataCollection<AnuncioDto>> GetAll(int page, int take)
        {
            return _anuncioService.GetAll(page, take);
        }
       
        [HttpGet("{id}")]
        public ActionResult<AnuncioDto> GetById(int id)
        {
            return _anuncioService.GetById(id);
        }
        [HttpPost]
        public ActionResult Create(AnuncioCreateDto anuncio)
        {
            _anuncioService.Create(anuncio);
            return Ok();
        }
        [HttpPut("{id}")]
        public ActionResult Update(int id, AnuncioUpdateDto model)
        {
            _anuncioService.Update(id, model);
            return NoContent();
        }
        [HttpDelete("{id}")]
        public ActionResult Remove(int id)
        {
            _anuncioService.Remove(id);
            return NoContent();
        }
    }
}

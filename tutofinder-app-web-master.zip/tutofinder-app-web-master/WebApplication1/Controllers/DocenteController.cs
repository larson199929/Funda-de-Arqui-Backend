﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiTodo.Commons;
using WebApplication1.Dto;
using WebApplication1.Model;
using WebApplication1.Service;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("docentes")]
    public class DocenteController : ControllerBase
    {
        private readonly DocenteService _docenteService;
        public DocenteController(DocenteService docenteService)
        {
            _docenteService = docenteService;
        }
        [HttpGet]
        public ActionResult<DataCollection<DocenteDto>> GetAll(int page, int take)
        {
            return _docenteService.GetAll(page, take);
        }
        [HttpGet("{id}")]
        public ActionResult<DocenteDto> GetById(int id)
        {
            return _docenteService.GetById(id);
        }
        [HttpPost]
        public ActionResult Create(DocenteCreateDto docente)
        {
            _docenteService.Create(docente);
            return Ok();
        }
        [HttpPut("{id}")]
        public ActionResult Update(int id, DocenteUpdateDto model)
        {
            _docenteService.Update(id, model);
            return NoContent();
        }
        [HttpDelete("{id}")]
        public ActionResult Remove(int id)
        {
            _docenteService.Remove(id);
            return NoContent();
        }
    }
}

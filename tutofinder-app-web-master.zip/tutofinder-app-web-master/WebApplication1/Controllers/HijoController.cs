﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiTodo.Commons;
using WebApplication1.Dto;
using WebApplication1.Service;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("hijos")]
    public class HijoController : ControllerBase
    {
        private readonly HijoService _hijoService;

        public HijoController(HijoService HijoService)
        {
            _hijoService = HijoService;
        }
        [HttpGet]
        public ActionResult<DataCollection<HijoDto>> GetAll(int page, int take)
        {
            return _hijoService.GetAll(page, take);
        }

        [HttpGet("{id}")]
        public ActionResult<HijoDto> GetById(int id)
        {
            return _hijoService.GetById(id);
        }
        [HttpPost]
        public ActionResult Create(HijoCreateDto Hijo)
        {
            _hijoService.Create(Hijo);
            return Ok();
        }
        [HttpPut("{id}")]
        public ActionResult Update(int id, HijoUpdateDto model)
        {
            _hijoService.Update(id, model);
            return NoContent();
        }
        [HttpDelete("{id}")]
        public ActionResult Remove(int id)
        {
            _hijoService.Remove(id);
            return NoContent();
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiTodo.Commons;
using WebApplication1.Dto;
using WebApplication1.Service;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("padres")]
    public class PadreController : ControllerBase
    {
        private readonly PadreService _padreService;

        public PadreController(PadreService PadreService)
        {
            _padreService = PadreService;
        }
        [HttpGet]
        public ActionResult<DataCollection<PadreDto>> GetAll(int page, int take)
        {
            return _padreService.GetAll(page, take);
        }

        [HttpGet("{id}")]
        public ActionResult<PadreDto> GetById(int id)
        {
            return _padreService.GetById(id);
        }
        [HttpPost]
        public ActionResult Create(PadreCreateDto Padre)
        {
            _padreService.Create(Padre);
            return Ok();
        }
        [HttpPut("{id}")]
        public ActionResult Update(int id, PadreUpdateDto model)
        {
            _padreService.Update(id, model);
            return NoContent();
        }
        [HttpDelete("{id}")]
        public ActionResult Remove(int id)
        {
            _padreService.Remove(id);
            return NoContent();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiTodo.Commons;
using WebApplication1.Dto;

namespace WebApplication1.Service
{
    public interface PadreService
    {
        DataCollection<PadreDto> GetAll(int page, int take);
        PadreDto GetById(int id);
        PadreDto Create(PadreCreateDto model);
        void Update(int id, PadreUpdateDto model);
        void Remove(int id);
    }
}

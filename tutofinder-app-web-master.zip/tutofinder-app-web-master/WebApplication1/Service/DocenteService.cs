﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiTodo.Commons;
using WebApplication1.Dto;

namespace WebApplication1.Service
{
    public interface DocenteService
    {
        DataCollection<DocenteDto> GetAll(int page, int take);
        DocenteDto GetById(int id);
        DocenteDto Create(DocenteCreateDto model);
        void Update(int id, DocenteUpdateDto model);
        void Remove(int id);
    }
}

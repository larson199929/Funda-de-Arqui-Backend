﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiTodo.Commons;
using WebApplication1.Dto;

namespace WebApplication1.Service
{
    public interface AnuncioService
    {
        DataCollection<AnuncioDto> GetAll(int page, int take);
        AnuncioDto GetById(int id);
        AnuncioDto Create(AnuncioCreateDto model);
        void Update(int id, AnuncioUpdateDto model);
        void Remove(int id);
    }
}

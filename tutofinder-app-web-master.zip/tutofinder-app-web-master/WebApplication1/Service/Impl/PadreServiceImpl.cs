﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiTodo.Commons;
using WebApplication1.Commons;
using WebApplication1.Dto;
using WebApplication1.Model;
using WebApplication1.Persistence;

namespace WebApplication1.Service.Impl
{
    public class PadreServiceImpl : PadreService
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;

        public PadreServiceImpl(ApplicationDbContext context,
            IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public PadreDto Create(PadreCreateDto model)
        {
            var entry = new Padre
            {
                Nombres = model.Nombres,
                Apellidos = model.Apellidos,
                Correo = model.Correo
            };
            _context.Add(entry);
            _context.SaveChanges();
            return _mapper.Map<PadreDto>(entry);
        }
        public void Remove(int id)
        {
            _context.Remove(new Padre
            {
                PadreId = id
            });
            _context.SaveChanges();
        }
        public void Update(int id,PadreUpdateDto model)
        {
            var entry = _context.Padres.Single(x => x.PadreId == id);
            entry.Nombres = model.Nombres;
            entry.Apellidos= model.Apellidos;
            entry.Correo = model.Correo;
            _context.SaveChanges();
        }
        public DataCollection<PadreDto> GetAll(int page, int take)
        {
            return _mapper.Map<DataCollection<PadreDto>>(
                _context.Padres
                .OrderByDescending(x => x.PadreId)
                .AsQueryable()
                .Paged(page, take));
        }
        public PadreDto GetById(int id)
        {
            return _mapper.Map<PadreDto>(_context.Padres.Single(x => x.PadreId == id));
        }
    }
}

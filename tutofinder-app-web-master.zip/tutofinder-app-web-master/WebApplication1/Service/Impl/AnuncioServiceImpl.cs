﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiTodo.Commons;
using WebApplication1.Commons;
using WebApplication1.Dto;
using WebApplication1.Model;
using WebApplication1.Persistence;

namespace WebApplication1.Service.Impl
{
    public class AnuncioServiceImpl : AnuncioService
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;

        

        public AnuncioServiceImpl(ApplicationDbContext context,IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public AnuncioDto Create(AnuncioCreateDto model)
        {
            var entry = new Anuncio
            {
                Area = model.Area,
                Curso = model.Curso,
                EtapaEscolar = model.EtapaEscolar,
                Duracion = model.Duracion,
                HoraInicio = model.HoraInicio,
                HoraFin= model.HoraFin
            };
            _context.Add(entry);
            _context.SaveChanges();

            return _mapper.Map<AnuncioDto>(entry);

        }
        public void Remove(int id)
        {
            _context.Remove(new Anuncio{
                AnuncioId = id
            });

            _context.SaveChanges();
        }
        public void Update(int id, AnuncioUpdateDto model)
        {
            var entry = _context.Anuncios.Single(x => x.AnuncioId == id);
            entry.Area = model.Area;
            entry.Curso = model.Curso;
            entry.EtapaEscolar = model.EtapaEscolar;
            entry.Duracion = model.Duracion;
            entry.HoraInicio = model.HoraFin;

            _context.SaveChanges();
        }

        public DataCollection<AnuncioDto> GetAll(int page, int take)
        {
            return _mapper.Map<DataCollection<AnuncioDto>>(
                _context.Anuncios
                .Include(x => x.Docente)
                .OrderByDescending(x => x.AnuncioId)
                .AsQueryable()
                .Paged(page, take));
        }
        public AnuncioDto GetById(int id)
        {
            return _mapper.Map<AnuncioDto>(
                _context.Anuncios.Single(x => x.AnuncioId == id));
        }
    }
}

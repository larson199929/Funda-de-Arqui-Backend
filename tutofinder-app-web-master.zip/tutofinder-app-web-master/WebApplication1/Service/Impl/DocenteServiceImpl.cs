﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiTodo.Commons;
using WebApplication1.Commons;
using WebApplication1.Dto;
using WebApplication1.Model;
using WebApplication1.Persistence;

namespace WebApplication1.Service.Impl
{
    public class DocenteServiceImpl : DocenteService
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;

        public DocenteServiceImpl(ApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }
        public DocenteDto Create(DocenteCreateDto model)
        {
            var entry = new Docente
            {
                Nombres = model.Nombres,
                Apellidos = model.Apellidos,
                Edad = model.Edad
            };

            _context.Add(entry);
            _context.SaveChanges();

            return _mapper.Map<DocenteDto>(entry);
        }
        public void Remove(int id)
        {
            _context.Remove(new Docente
            {
                DocenteId = id
            });
            _context.SaveChanges();
        }

        public void Update(int id, DocenteUpdateDto model)
        {
            var entry = _context.Docentes.Single(x => x.DocenteId == id);
            entry.Nombres = model.Nombres;
            entry.Apellidos = model.Apellidos;
            entry.Edad = model.Edad;
        }
        public DataCollection<DocenteDto> GetAll(int page, int take)
        {
            return _mapper.Map<DataCollection<DocenteDto>>(
                _context.Docentes
                .OrderByDescending(x => x.DocenteId)
                .AsQueryable()
                .Paged(page, take));
        }
        public DocenteDto GetById(int id)
        {
            return _mapper.Map<DocenteDto>(
                _context.Docentes.Single(x => x.DocenteId == id));
        }
    }

   
}

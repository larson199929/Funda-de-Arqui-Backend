﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiTodo.Commons;
using WebApplication1.Commons;
using WebApplication1.Dto;
using WebApplication1.Model;
using WebApplication1.Persistence;

namespace WebApplication1.Service.Impl
{
    public class HijoServiceImpl : HijoService
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;

        public HijoServiceImpl(ApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public HijoDto Create(HijoCreateDto model)
        {
            var entry = new Hijo
            {
                Nombres = model.Nombres,
                AñoEscolar= model.AñoEscolar,
            };
            _context.Add(entry);
            _context.SaveChanges();
            return _mapper.Map<HijoDto>(entry);
        }
        public void Remove(int id)
        {
            _context.Remove(new Hijo
            {
                HijoId=id
            });

            _context.SaveChanges();
        }
        public void Update(int id, HijoUpdateDto model)
        {
            var entry = _context.Hijos.Single(x => x.HijoId == id);
            entry.Nombres = model.Nombres;
            entry.AñoEscolar = model.AñoEscolar;
            _context.SaveChanges();
        }
        public DataCollection<HijoDto> GetAll(int page, int take)
        {
            return _mapper.Map<DataCollection<HijoDto>>(
                _context.Hijos
                .Include(x => x.Padre)
                .OrderByDescending(x => x.HijoId)
                .AsQueryable()
                .Paged(page, take));
        }
        public HijoDto GetById(int id)
        {
            return _mapper.Map<HijoDto>(
                _context.Hijos.Single(x => x.HijoId == id));
        }
    }
}

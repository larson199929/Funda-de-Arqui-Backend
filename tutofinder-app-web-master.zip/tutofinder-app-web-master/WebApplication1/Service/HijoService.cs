﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiTodo.Commons;
using WebApplication1.Dto;

namespace WebApplication1.Service
{
    public interface HijoService
    {
        DataCollection<HijoDto> GetAll(int page, int take);
        HijoDto GetById(int id);
        HijoDto Create(HijoCreateDto model);
        void Update(int id, HijoUpdateDto model);
        void Remove(int id);

    }
}

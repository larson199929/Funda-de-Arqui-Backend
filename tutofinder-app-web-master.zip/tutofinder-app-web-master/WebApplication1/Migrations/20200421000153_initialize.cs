﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication1.Migrations
{
    public partial class initialize : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Docentes",
                columns: table => new
                {
                    DocenteId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombres = table.Column<string>(maxLength: 20, nullable: false),
                    Apellidos = table.Column<string>(maxLength: 20, nullable: false),
                    Edad = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Docentes", x => x.DocenteId);
                });

            migrationBuilder.CreateTable(
                name: "Padres",
                columns: table => new
                {
                    PadreId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombres = table.Column<string>(maxLength: 20, nullable: false),
                    Apellidos = table.Column<string>(maxLength: 20, nullable: false),
                    Correo = table.Column<string>(maxLength: 30, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Padres", x => x.PadreId);
                });

            migrationBuilder.CreateTable(
                name: "Anuncios",
                columns: table => new
                {
                    AnuncioId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Area = table.Column<string>(maxLength: 30, nullable: false),
                    Curso = table.Column<string>(maxLength: 20, nullable: false),
                    EtapaEscolar = table.Column<string>(maxLength: 10, nullable: false),
                    Duracion = table.Column<double>(nullable: false),
                    HoraInicio = table.Column<double>(nullable: false),
                    HoraFin = table.Column<double>(nullable: false),
                    Docente_Id = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Anuncios", x => x.AnuncioId);
                    table.ForeignKey(
                        name: "FK_Anuncios_Docentes_Docente_Id",
                        column: x => x.Docente_Id,
                        principalTable: "Docentes",
                        principalColumn: "DocenteId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Hijos",
                columns: table => new
                {
                    HijoId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombres = table.Column<string>(maxLength: 20, nullable: false),
                    AñoEscolar = table.Column<string>(maxLength: 20, nullable: false),
                    Padre_Id = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Hijos", x => x.HijoId);
                    table.ForeignKey(
                        name: "FK_Hijos_Padres_Padre_Id",
                        column: x => x.Padre_Id,
                        principalTable: "Padres",
                        principalColumn: "PadreId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Docentes",
                columns: new[] { "DocenteId", "Apellidos", "Edad", "Nombres" },
                values: new object[] { 1, " Bustos Avila", 28, " Henrry Paul" });

            migrationBuilder.InsertData(
                table: "Docentes",
                columns: new[] { "DocenteId", "Apellidos", "Edad", "Nombres" },
                values: new object[] { 2, " Molina Perez", 31, " Moises Eduardo" });

            migrationBuilder.InsertData(
                table: "Padres",
                columns: new[] { "PadreId", "Apellidos", "Correo", "Nombres" },
                values: new object[] { 1, " Avila Santos", " clothy22@gmail.com ", " Clothy Silvia" });

            migrationBuilder.InsertData(
                table: "Anuncios",
                columns: new[] { "AnuncioId", "Area", "Curso", "Docente_Id", "Duracion", "EtapaEscolar", "HoraFin", "HoraInicio" },
                values: new object[,]
                {
                    { 1, " MATEMÁTICA", " ÁLGEBRA", 1, 1.5, "SECUNDARIA", 5.5, 4.0 },
                    { 2, " COMUNICACIÓN", " LENGUAJE", 2, 1.5, "PRIMARIA", 4.5, 3.0 }
                });

            migrationBuilder.InsertData(
                table: "Hijos",
                columns: new[] { "HijoId", "AñoEscolar", "Nombres", "Padre_Id" },
                values: new object[,]
                {
                    { 1, " SECUNDARIA", " Royer Felix", 1 },
                    { 2, " SECUNDARIA", " Salvador Victor", 1 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Anuncios_Docente_Id",
                table: "Anuncios",
                column: "Docente_Id");

            migrationBuilder.CreateIndex(
                name: "IX_Hijos_Padre_Id",
                table: "Hijos",
                column: "Padre_Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Anuncios");

            migrationBuilder.DropTable(
                name: "Hijos");

            migrationBuilder.DropTable(
                name: "Docentes");

            migrationBuilder.DropTable(
                name: "Padres");
        }
    }
}

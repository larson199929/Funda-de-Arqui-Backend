﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Model;
using WebApplication1.Persistence.Config;

namespace WebApplication1.Persistence
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {

        }
        public DbSet<Padre> Padres { get; set; }
        public DbSet<Docente> Docentes { get; set; }
        public DbSet<Anuncio> Anuncios { get; set; }
        public DbSet<Hijo> Hijos { get; set; }
       
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            new AnuncioConfig(builder.Entity<Anuncio>());
            new DocenteConfig(builder.Entity<Docente>());
            new HijoConfig(builder.Entity<Hijo>());
            new PadreConfig(builder.Entity<Padre>());
          
        }
    }
}

﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Model;

namespace WebApplication1.Persistence.Config
{
    public class AnuncioConfig
    {
        public AnuncioConfig(EntityTypeBuilder<Anuncio> entityBuilder)
        {
            entityBuilder.Property(x => x.Curso)
                .IsRequired().HasMaxLength(20);
            entityBuilder.Property(x => x.Area)
                .IsRequired().HasMaxLength(30);
            entityBuilder.Property(x => x.EtapaEscolar)
                .IsRequired().HasMaxLength(10);
            entityBuilder.HasOne(x => x.Docente)
                .WithMany(x => x.Anuncios)
                .HasForeignKey(x => x.Docente_Id);
            entityBuilder.HasData(
                new Anuncio
                {
                    AnuncioId=1,
                    Area = " MATEMÁTICA",
                    Curso = " ÁLGEBRA",
                    EtapaEscolar = "SECUNDARIA",
                    Duracion = 1.5,
                    HoraInicio = 4,
                    HoraFin = 5.5,
                    Docente_Id=1
                },
                 new Anuncio
                 {
                     AnuncioId = 2,
                     Area = " COMUNICACIÓN",
                     Curso = " LENGUAJE",
                     EtapaEscolar = "PRIMARIA",
                     Duracion = 1.5,
                     HoraInicio = 3,
                     HoraFin = 4.5,
                     Docente_Id= 2
                 });
        }
    }
}

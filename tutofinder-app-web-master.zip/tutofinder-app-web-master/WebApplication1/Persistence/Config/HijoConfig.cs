﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Model;

namespace WebApplication1.Persistence.Config
{
    public class HijoConfig
    {
        public HijoConfig(EntityTypeBuilder<Hijo> entityBuilder)
        {
            entityBuilder.Property(x => x.Nombres)
                .IsRequired().HasMaxLength(20);
            entityBuilder.Property(x => x.AñoEscolar)
                .IsRequired().HasMaxLength(20);
            entityBuilder.HasOne(x => x.Padre)
                .WithMany(x => x.Hijos)
                .HasForeignKey(x => x.Padre_Id);
            entityBuilder.HasData(
                new Hijo
                {
                    HijoId = 1,
                    Nombres = " Royer Felix",
                    AñoEscolar = " SECUNDARIA",
                    Padre_Id = 1
                    
                },
                 new Hijo
                 {
                     HijoId = 2,
                     Nombres = " Salvador Victor",
                     AñoEscolar = " SECUNDARIA",
                     Padre_Id = 1
                 });
        }
    }
}

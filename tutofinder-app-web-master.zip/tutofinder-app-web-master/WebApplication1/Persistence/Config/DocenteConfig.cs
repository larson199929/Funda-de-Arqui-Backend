﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Model;

namespace WebApplication1.Persistence.Config
{
    public class DocenteConfig
    {
        public DocenteConfig(EntityTypeBuilder<Docente> entityBuilder)
        {
            entityBuilder.Property(x => x.Nombres)
                .IsRequired().HasMaxLength(20);
            entityBuilder.Property(x => x.Apellidos)
                .IsRequired().HasMaxLength(20);
            entityBuilder.HasData(
                new Docente
                {
                    DocenteId = 1,
                    Nombres = " Henrry Paul",
                    Apellidos = " Bustos Avila",
                    Edad = 28,
                },
                new Docente
                {
                    DocenteId = 2,
                    Nombres = " Moises Eduardo",
                    Apellidos = " Molina Perez",
                    Edad = 31,
                }


            );
         }
    }
}

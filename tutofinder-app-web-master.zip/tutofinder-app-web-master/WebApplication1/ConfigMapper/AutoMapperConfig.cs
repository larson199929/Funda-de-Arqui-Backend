﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiTodo.Commons;
using WebApplication1.Dto;
using WebApplication1.Model;

namespace WebApplication1.ConfigMapper
{
    public class AutoMapperConfig : Profile
    {
        public AutoMapperConfig(){

            CreateMap<Anuncio,AnuncioDto>();
            CreateMap<DataCollection<Anuncio>,DataCollection<AnuncioDto>>();

            CreateMap<Docente, DocenteDto>();
            CreateMap<DataCollection<Docente>, DataCollection<DocenteDto>>();

            CreateMap<Hijo, HijoDto>();
            CreateMap<DataCollection<Hijo>, DataCollection<HijoDto>>();

            CreateMap<Padre, PadreDto>();
            CreateMap<DataCollection<Padre>, DataCollection<PadreDto>>();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Model
{
    public class Anuncio
    {
        public int AnuncioId { get; set; }
        public string Area { get; set; }
        public string Curso { get; set; }
        public string EtapaEscolar { get; set; }
        public double Duracion { get; set; }
        public double HoraInicio { get; set; }
        public double HoraFin { get; set; }
        public int Docente_Id { get; set; }
        public Docente Docente { get; set; }
    }
}

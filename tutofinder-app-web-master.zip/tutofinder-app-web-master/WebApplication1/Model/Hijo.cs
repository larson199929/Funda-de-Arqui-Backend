﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Model
{
    public class Hijo
    {
        public int HijoId { get; set; }
        public string Nombres { get; set; }
        public string AñoEscolar { get; set; }
        public int Padre_Id { get; set; }
        public Padre Padre { get; set; }
    }
}
